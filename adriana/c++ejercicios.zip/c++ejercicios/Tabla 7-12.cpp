#include <iostream>

using namespace std;

int main()
{
    cout<<"Ejemplo del bucle for";
    
    int tabla=7;
    for(int k=12; k>=1; k--)
 {
     cout<<endl<<"tabla 7 " << " x " << k << " = " << (tabla * k);
    
 }

return 0;

}