#include <iostream>

using namespace std;

int main()
{
    cout<<"ejemplo del buble while";

    int i=0;
    while(i <10)
    {
        i++;
        cout<<endl<<"mensaje # :" << i;
        cout<<endl<<"el cuadrado de i:" << (i*i);
    }
    return 0;
}